import { Component } from '@angular/core';

@Component({
  selector: 'app-adminhome',
  standalone: true,
  imports: [],
  templateUrl: './adminhome.component.html',
  styleUrl: './adminhome.component.css'
})
export class AdminhomeComponent {

}
