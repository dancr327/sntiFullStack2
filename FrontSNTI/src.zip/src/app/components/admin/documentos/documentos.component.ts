

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { NgForm } from '@angular/forms';
import { AdminbarraComponent } from '../adminbarra/adminbarra.component';




@Component({
  selector: 'app-documentos',
  standalone: true,
  imports: [CommonModule, FormsModule, AdminbarraComponent],
  templateUrl: './documentos.component.html',
  styleUrls: ['./documentos.component.css']
})
export class DocumentosComponent  {

  

  





}